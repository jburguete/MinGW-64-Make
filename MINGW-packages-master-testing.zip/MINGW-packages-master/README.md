MINGW-packages
==============

Package scripts for MinGW-w64 targets to build under MSYS2.
