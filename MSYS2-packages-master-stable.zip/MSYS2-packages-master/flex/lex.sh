#!/bin/sh

exec /usr/bin/flex -l "$@"
